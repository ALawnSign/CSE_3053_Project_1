user/nice.o: user/nice.c user/user.h kernel/types.h
