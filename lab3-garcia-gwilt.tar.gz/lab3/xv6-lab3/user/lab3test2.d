user/lab3test2.o: user/lab3test2.c kernel/types.h kernel/stat.h \
 kernel/fcntl.h user/user.h
